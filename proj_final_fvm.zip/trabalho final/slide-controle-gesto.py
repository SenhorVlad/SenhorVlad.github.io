#trabalho de controle de slide por gesto
#equipe FVM:
#Muriel Da Costa Santos RA:11201723059
#Fernando Cezar Resende Lopes RA: 11201811290
#Vinícius De Souza Nascimento RA: 11201810059
#
#Para iniciar o programa, execute o comando: $python3 slide-controle-gesto.py



from cvzone.HandTrackingModule import HandDetector
from cvzone.SelfiSegmentationModule import SelfiSegmentation
import cv2
import os
import numpy as np
import imutils
from matplotlib import pyplot as plt

width, height = 960, 540
gestureThreshold = 50
folderPath = "slide"
cap = cv2.VideoCapture(0)
cap.set(3, width)
cap.set(4, height)
detectorHand = HandDetector(detectionCon=0.8, maxHands=1)
imgList = []
delay = 30
buttonPressed = False
counter = 0
drawMode = False
imgNumber = 0
delayCounter = 0
annotations = [[]]
annotationNumber = -1
annotationStart = False
hs, ws = int(120 * 1), int(213 * 1)
pathImages = sorted(os.listdir(folderPath))
print(pathImages)

atual_image = cv2.imread(os.path.join(folderPath, pathImages[imgNumber]))
zoom_flag = False;
    
def zoom(img, zoom_factor=1.8):
    return cv2.resize(img, None, fx=zoom_factor, fy=zoom_factor)

bg_subtractor = cv2.createBackgroundSubtractorMOG2()

counter = 0
segmentor = SelfiSegmentation()

while True:
    # Get image frame
    success, img = cap.read()
    img = cv2.blur(img, (2,2)) #applying blur filter
    
    #img = cv2.cvtColor(img, cv2.COLOR_BGR2HSV) #apply color filter(gray)
        
    img = cv2.flip(img, 1)

    img_yuv = cv2.cvtColor(img, cv2.COLOR_BGR2YUV)
    # equalize the histogram of the Y channel
    img_yuv[:,:,0] = cv2.equalizeHist(img_yuv[:,:,0])

    # convert the YUV image back to RGB format
    img = cv2.cvtColor(img_yuv, cv2.COLOR_YUV2BGR) 
    
    

    pathFullImage = os.path.join(folderPath, pathImages[imgNumber])
    if zoom_flag :
        imgCurrent = zoom(cv2.imread(pathFullImage), 1.8)
    else:
        imgCurrent = zoom(cv2.imread(pathFullImage), 1)


    hist = cv2.calcHist([img], [0], None, [256], [0, 256])
    hist_max = np.max(hist)
    hist_img = np.zeros((height, ws, 3), dtype=np.uint8)
    for i in range(256):
        h = int(hist[i] * height / hist_max)
        cv2.line(hist_img, (i, height), (i, height - h), (0, 255, 0), 1)

    #cv2.imshow("Histogram", hist_img)

    hands, img = detectorHand.findHands(img)  # with draw
    img =  segmentor.removeBG(img, (0, 255, 0))

    if hands and buttonPressed is False:  # If hand is detected

        hand = hands[0]
        cx, cy = hand["center"]
        lmList = hand["lmList"]  # List of 21 Landmark points
        fingers = detectorHand.fingersUp(hand)  # List of which fingers are up

        # mexer no valor de width para escalonar o cursor no eixo X. 200 ficou bom.
        xVal = int(np.interp(lmList[8][0], [width // 6, width//2], [0, width*2]))
        yVal = int(np.interp(lmList[8][1], [150, height-250], [0, height*2]))
        indexFinger = xVal, yVal

        #if cy <= gestureThreshold:  # If hand is at the height of the face
        if fingers == [1, 0, 0, 0, 0]:
            print("Left")
            buttonPressed = True
            if imgNumber > 0:
                imgNumber -= 1
                annotations = [[]]
                annotationNumber = -1
                annotationStart = False
        if fingers == [0, 0, 0, 0, 1]:
            print("Right")
            buttonPressed = True
            if imgNumber < len(pathImages) - 1:
                imgNumber += 1
                annotations = [[]]
                annotationNumber = -1
                annotationStart = False
        if fingers == [1, 1, 0, 0, 0]:
            print("zoom in")
            zoom_flag = True
            buttonPressed = True
            #imgCurrent = Zoom(imgCurrent, 2)
            imgCurrent = zoom(imgCurrent, 1.8)
            atual_image = imgCurrent
            #cv2.imshow("Slides", imgCurrent)

        if fingers == [1, 0, 0, 0, 1]:
            print("zoom out")
            zoom_flag = False
            buttonPressed = True
            #imgCurrent = Zoom(imgCurrent, 2)
            imgCurrent = zoom(imgCurrent, 1)
            atual_image = imgCurrent
            #cv2.imshow("Slides", imgCurrent)


        if fingers == [0, 1, 1, 0, 0]:
            cv2.circle(imgCurrent, indexFinger, 12, (0, 0, 255), cv2.FILLED)

        if fingers == [0, 1, 0, 0, 0]:
            if annotationStart is False:
                annotationStart = True
                annotationNumber += 1
                annotations.append([])
            print(annotationNumber)
            annotations[annotationNumber].append(indexFinger)
            cv2.circle(imgCurrent, indexFinger, 12, (0, 0, 255), cv2.FILLED)

        else:
            annotationStart = False

        if fingers == [0, 1, 1, 1, 0]:
            if annotations:
                annotations.pop(-1)
                annotationNumber -= 1
                buttonPressed = True

    else:
        annotationStart = False

    if buttonPressed:
        counter += 1
        if counter > delay:
            counter = 0
            buttonPressed = False

    for i, annotation in enumerate(annotations):
        for j in range(len(annotation)):
            if j != 0:
                cv2.line(imgCurrent, annotation[j - 1], annotation[j], (0, 0, 200), 12)

    imgSmall = cv2.resize(img, (ws, hs))
    h, w, _ = imgCurrent.shape
    imgCurrent[0:hs, w - ws: w] = imgSmall

    
    cv2.imshow("controle de slide por gesto | Equipe FVM", imgCurrent)
    #cv2.imshow("img", img)
    #cv2.imshow("Image", img)

    key = cv2.waitKey(1)
    if key == ord('q'):
        break
